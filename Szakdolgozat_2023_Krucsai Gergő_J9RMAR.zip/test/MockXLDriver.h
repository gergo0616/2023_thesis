#include <gmock/gmock.h>
#include "../include/libs/bin/vxlapi.h"

class MockLibs {
public:
    MOCK_METHOD(XLstatus, xlCanTransmitEx, (XLportHandle, XLaccess, unsigned int, unsigned int*, XLcanTxEvent*), (const));
    MOCK_METHOD(XLstatus, xlCanTransmit, (XLportHandle, XLaccess, unsigned int*, XLevent*), (const));
    //MOCK_METHOD(const char*, MockxlGetErrorString, (XLstatus));
};