#include <gtest/gtest.h>
#include "../Services/services.hpp"
#include <fstream>
#include <string>

class ServicesTest : public ::testing::Test {
protected:
    Services service;
};

TEST_F(ServicesTest, EncodeUDStoCANTest) {
    std::string udsMsg = "Test";
    std::vector<uint8_t> canFrame = service.translateUdsToCan(udsMsg);

    std::vector<uint8_t> expectedFrame = { 'T', 'e', 's', 't' };
    EXPECT_EQ(canFrame, expectedFrame);
}

TEST_F(ServicesTest, DecodeCANtoUDSTest) {
    std::vector<uint8_t> canFrame = { 'T', 'e', 's', 't' };
    std::string udsMsg = service.translateCanToUds(canFrame);

    EXPECT_EQ(udsMsg, "Test");
}









