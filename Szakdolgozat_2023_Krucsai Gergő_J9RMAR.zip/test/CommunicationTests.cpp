#include <windows.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "../include/libs/bin/vxlapi.h"
#include "../Communication/transmission.hpp"
#include "../Config/helper.hpp"
#include "MockXLDriver.h"

//unsigned int g_canFdSupport = 1;    // High speed available
//XLportHandle g_xlPortHandle = 0;

MockLibs* g_mockLibs;

XLstatus xlCanTransmitEx(XLportHandle portHandle, XLaccess xlChanMaskTx, unsigned int messageCount, unsigned int* cntSent, XLcanTxEvent* canTxEvt) {
    return g_mockLibs->xlCanTransmitEx(portHandle, xlChanMaskTx, messageCount, cntSent, canTxEvt);
}

XLstatus xlCanTransmit(XLportHandle portHandle, XLaccess xlChanMaskTx, unsigned int* messageCount, XLevent* xlEvent) {
    return g_mockLibs->xlCanTransmit(portHandle, xlChanMaskTx, messageCount, xlEvent);
}

TEST(TransmissionTest, TestCanFDTransmit) {
    MockLibs mockLibs;
    g_mockLibs = &mockLibs;

    // Set the global variables for the test
    bool canFdSupport = 1;
    XLportHandle xlPortHandle = 0; /* some valid handle */;

    unsigned int txID = 1000;
    XLaccess xlChanMaskTx = 1;

    // Set expectation based on the value of canFdSupport
    if (canFdSupport) {
        EXPECT_CALL(mockLibs, xlCanTransmitEx(::testing::_, xlChanMaskTx, ::testing::_, ::testing::_, ::testing::_))
            .WillOnce(::testing::Return(XL_SUCCESS));
    } else {
        EXPECT_CALL(mockLibs, xlCanTransmit(::testing::_, xlChanMaskTx, ::testing::_, ::testing::_))
            .WillOnce(::testing::Return(XL_SUCCESS));
    }

    std::vector<uint8_t> emptyData;
    XLstatus result = transmit(txID, xlChanMaskTx, emptyData);

    EXPECT_EQ(result, XL_SUCCESS);
}





