#include <gtest/gtest.h>
#include "../Parser/parser.hpp"

TEST(ParserTest, ParseIntTest) {
    EXPECT_EQ(42, ParseInt("42"));
    EXPECT_EQ(0, ParseInt("0"));
    EXPECT_EQ(-42, ParseInt("-42"));
    EXPECT_EQ(0, ParseInt("abc"));  // This should return 0
}

