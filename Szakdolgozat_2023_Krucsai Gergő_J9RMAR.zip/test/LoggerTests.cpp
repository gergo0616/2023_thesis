#include <gtest/gtest.h>
#include <fstream>
#include <string>
#include "../Logger/logging.hpp"
#include <cstdio> 

TEST(LogToFileTest, LogOutputTest) {
    // Clearing the log file
    std::ofstream logFile("log.txt", std::ios::trunc);
    logFile.close();

    std::string message = "Test log message";
    logToFile(message);

    std::ifstream logFileIn("log.txt");
    std::string loggedMessage;

    if (logFileIn.is_open()) {
        std::getline(logFileIn, loggedMessage);
        logFileIn.close();
    }

    EXPECT_EQ(loggedMessage, message);
}
