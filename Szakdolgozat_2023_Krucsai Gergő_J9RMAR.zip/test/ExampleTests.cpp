#include "../Example.hpp"
#include <gtest/gtest.h>


TEST(ExampleTests, DemonstrateGTestMacros){
    const bool result = unit_test(6);
    EXPECT_EQ(true, result);
}
