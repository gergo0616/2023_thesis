#include "../include/libs/bin/vxlapi.h"
#include <vector>
#include <sstream>
#include <iostream>
#include <array>
#ifndef TRANSMISSION_HPP
#define TRANSMISSION_HPP

XLstatus transmit(unsigned int txID, XLaccess xlChanMaskTx, std::vector<uint8_t> data);

XLcanRxEvent reception(int timeoutInSeconds);

XLstatus initDriver(XLaccess *pxlChannelMaskTx, unsigned int *pxlChannelIndex, char* app_name, bool can_fd);

#endif