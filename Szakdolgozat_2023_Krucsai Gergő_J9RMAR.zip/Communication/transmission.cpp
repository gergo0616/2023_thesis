#include <windows.h>
#include "../include/libs/bin/vxlapi.h"
#include "transmission.hpp"
#include "../Config/helper.hpp"
#include <iostream>
#include <sstream>
#include <string>
#include <array>
#include <vector>
#include <chrono>

#define RX_QUEUE_SIZE_FD           16384 // driver queue size for CAN-FD Rx events
#define RX_QUEUE_SIZE              4096     // internal driver queue size in CAN events


using namespace std;

unsigned int canFdSupport = 0;
XLportHandle g_xlPortHandle;

XLaccess g_xlChannelMask;
XLdriverConfig  g_xlDrvConfig;
unsigned int g_canFdModeNoIso;

XLaccess        g_xlPermissionMask          = 0;                          //!< Global permissionmask (includes all founded channels)
unsigned int    g_BaudRate                  = 500000;                     //!< Default baudrate

XLstatus transmit(unsigned int txID, XLaccess xlChanMaskTx, std::vector<uint8_t> data)
{
  XLstatus             xlStatus;
  unsigned int         messageCount = 1;
  static int           cnt = 0;

  if (canFdSupport) {
    XLcanTxEvent canTxEvt;
    unsigned int cntSent;

    memset(&canTxEvt, 0, sizeof(canTxEvt));
    canTxEvt.tag = XL_CAN_EV_TAG_TX_MSG;

    canTxEvt.tagData.canMsg.canId = txID;
    canTxEvt.tagData.canMsg.msgFlags = XL_CAN_TXMSG_FLAG_EDL; // Always CAN FD
    canTxEvt.tagData.canMsg.dlc = 15; // DLC for CAN FD (64 bytes)

    
    for (size_t i = 0; i < data.size() && i < XL_CAN_MAX_DATA_LEN; i++) {
        canTxEvt.tagData.canMsg.data[i] = data[i];
    }

    xlStatus = xlCanTransmitEx(g_xlPortHandle, xlChanMaskTx, messageCount, &cntSent, &canTxEvt);
    std::cout << "Sent on CAN FD" << std::endl;
}
  else {
    static XLevent       xlEvent;
   
    memset(&xlEvent, 0, sizeof(xlEvent));

    xlEvent.tag                 = XL_TRANSMIT_MSG;
    xlEvent.tagData.msg.id      = txID;
    xlEvent.tagData.msg.dlc     = 8;
    xlEvent.tagData.msg.flags   = 0;
    xlEvent.tagData.msg.data[0] = 1;
    xlEvent.tagData.msg.data[1] = 2;
    xlEvent.tagData.msg.data[2] = 3;
    xlEvent.tagData.msg.data[3] = 4;
    xlEvent.tagData.msg.data[4] = 5;
    xlEvent.tagData.msg.data[5] = 6;
    xlEvent.tagData.msg.data[6] = 7;
    xlEvent.tagData.msg.data[7] = 8;

    xlStatus = xlCanTransmit(g_xlPortHandle, xlChanMaskTx, &messageCount, &xlEvent);
    std::cout << "Sent on Simple CAN Frame" <<std::endl;
  }

  printf("- Transmit         : CM(0x%I64x), %s\n", xlChanMaskTx, xlGetErrorString(xlStatus));
  
  return xlStatus;
}

XLcanRxEvent reception(int timeoutInSeconds) {
    XLstatus xlStatus;
    XLcanRxEvent xlCanEvent = {};

    // Convert timeout from seconds to milliseconds
    int timeoutInMilliseconds = timeoutInSeconds * 1000;

    // Check if the timeout value is invalid
    if (timeoutInMilliseconds < 0) {
        // Set default timeout value
        timeoutInMilliseconds = 5000; // 5 seconds
    }

    auto start_time = std::chrono::high_resolution_clock::now();
    do {
        xlStatus = xlCanReceive(g_xlPortHandle, &xlCanEvent);
        if (xlStatus != XL_ERR_QUEUE_IS_EMPTY) {
            break;
        }
    } while (std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::high_resolution_clock::now() - start_time).count() < timeoutInMilliseconds);

    return xlCanEvent;
}

XLstatus initDriver(XLaccess *pxlChannelMaskTx, unsigned int *pxlChannelIndex, char* app_name, bool can_fd) {
  
  XLstatus xlStatus;
  XLaccess xlChannelMaskFd = 0;
  XLaccess xlChannelMaskFdNoIso = 0;

  // open the driver
  xlStatus = xlOpenDriver();

  // get/print the hardware configuration
  if(XL_SUCCESS == xlStatus) {
    xlStatus = xlGetDriverConfig(&g_xlDrvConfig);
  }

  if(XL_SUCCESS == xlStatus) {
    // select the wanted channels
    g_xlChannelMask = 0;
    for (unsigned int i=0; i < g_xlDrvConfig.channelCount; i++) {

      // we take all hardware we found and supports CAN
      if (g_xlDrvConfig.channel[i].channelBusCapabilities & XL_BUS_ACTIVE_CAP_CAN) {

        if (!*pxlChannelMaskTx) {
          *pxlChannelMaskTx = g_xlDrvConfig.channel[i].channelMask;
          *pxlChannelIndex  = g_xlDrvConfig.channel[i].channelIndex;
        }

        // check if we can use CAN FD - the virtual CAN driver supports CAN-FD, but we don't use it
        if ((g_xlDrvConfig.channel[i].channelCapabilities & XL_CHANNEL_FLAG_CANFD_ISO_SUPPORT)
           && (g_xlDrvConfig.channel[i].hwType != XL_HWTYPE_VIRTUAL)) {
          xlChannelMaskFd |= g_xlDrvConfig.channel[i].channelMask;

          // check CAN FD NO ISO support
          if (g_xlDrvConfig.channel[i].channelCapabilities & XL_CHANNEL_FLAG_CANFD_BOSCH_SUPPORT) {
            xlChannelMaskFdNoIso |= g_xlDrvConfig.channel[i].channelMask;
          }
        }
        else {
          g_xlChannelMask |= g_xlDrvConfig.channel[i].channelMask;
        }
      }
    }

    // if we found a CAN FD supported channel - we use it.
    if (xlChannelMaskFd && !g_canFdModeNoIso) {
      g_xlChannelMask = xlChannelMaskFd;
      printf("- Use CAN-FD for   : CM=0x%I64x\n", g_xlChannelMask);
      canFdSupport = 1;
    }

    if (xlChannelMaskFdNoIso && g_canFdModeNoIso) {
      g_xlChannelMask = xlChannelMaskFdNoIso;
      printf("- Use CAN-FD NO ISO for   : CM=0x%I64x\n", g_xlChannelMask);
      canFdSupport = 1;
    }

    if (!g_xlChannelMask) {
      cout << "ERROR: no available channels found! (e.g. no CANcabs...)\n\n";
      xlStatus = XL_ERROR;
    }
  }

  g_xlPermissionMask = g_xlChannelMask;

  if(XL_SUCCESS == xlStatus) {

    // check if we can use CAN FD
    if (canFdSupport) {
      xlStatus = xlOpenPort(&g_xlPortHandle, app_name, g_xlChannelMask, &g_xlPermissionMask, RX_QUEUE_SIZE_FD, XL_INTERFACE_VERSION_V4, XL_BUS_TYPE_CAN);
    }
    // if not, we make 'normal' CAN
    else {
      xlStatus = xlOpenPort(&g_xlPortHandle, app_name, g_xlChannelMask, &g_xlPermissionMask, RX_QUEUE_SIZE, XL_INTERFACE_VERSION, XL_BUS_TYPE_CAN);

    }
    printf("- OpenPort         : CM=0x%I64x, PH=0x%02X, PM=0x%I64x, %s\n",
      g_xlChannelMask, g_xlPortHandle, g_xlPermissionMask, xlGetErrorString(xlStatus));

  }

  if ( (XL_SUCCESS == xlStatus) && (XL_INVALID_PORTHANDLE != g_xlPortHandle) ) {

    if (g_xlChannelMask == g_xlPermissionMask) {

      if(canFdSupport) {
        XLcanFdConf fdParams = {};

        // arbitration bitrate
        fdParams.arbitrationBitRate = 1000000;
        fdParams.tseg1Abr           = 6;
        fdParams.tseg2Abr           = 3;
        fdParams.sjwAbr             = 2;

        // data bitrate
        fdParams.dataBitRate = fdParams.arbitrationBitRate*2;
        fdParams.tseg1Dbr    = 6;
        fdParams.tseg2Dbr    = 3;
        fdParams.sjwDbr      = 2;

        if (g_canFdModeNoIso) {
          fdParams.options = CANFD_CONFOPT_NO_ISO;
        }

        xlStatus = xlCanFdSetConfiguration(g_xlPortHandle, g_xlChannelMask, &fdParams);
        printf("- SetFdConfig.     : ABaudr.=%u, DBaudr.=%u, %s\n", fdParams.arbitrationBitRate,
              fdParams.dataBitRate, xlGetErrorString(xlStatus));

      }
      else {
        xlStatus = xlCanSetChannelBitrate(g_xlPortHandle, g_xlChannelMask, g_BaudRate);
        printf("- SetChannelBitrate: baudr.=%u, %s\n",g_BaudRate, xlGetErrorString(xlStatus));
      }
    }
    else {
      cout << "-                  : we have NO init access!\n";
    }
  }
  else {

    xlClosePort(g_xlPortHandle);
    g_xlPortHandle = XL_INVALID_PORTHANDLE;
    xlStatus = XL_ERROR;
  }

  if(XL_SUCCESS == xlStatus) {
            // ------------------------------------
            // go with all selected channels on bus
            // ------------------------------------
            xlStatus = xlActivateChannel(g_xlPortHandle, g_xlChannelMask, XL_BUS_TYPE_CAN, XL_ACTIVATE_RESET_CLOCK);
            printf("- ActivateChannel  : CM=0x%I64x, %s\n", g_xlChannelMask, xlGetErrorString(xlStatus));
            //if(status == XL_SUCCESS) activated = 1;
        }

  return xlStatus;
}