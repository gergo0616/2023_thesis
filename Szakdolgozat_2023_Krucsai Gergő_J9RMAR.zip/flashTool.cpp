#if defined(_Windows) || defined(_MSC_VER) || defined (__GNUC__)
 #define  STRICT
 #include <windows.h>
#endif

#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <array>
#include <conio.h>

// Vector XL Driver
#include "include/libs/bin/vxlapi.h"

// Communication
#include "Communication/transmission.hpp"

// Config
#include "Config/helper.hpp"
#include "Config/XMLConfig.hpp"

// Parser
#include "Parser/parser.hpp"

// Services
#include "Services/CAN.hpp"
#include "Services/CANBus.hpp"
#include "Services/CANisoTP.hpp"
#include "Services/CANisoTP.hpp"
#include "Services/UDSonCAN.hpp"

// Tester
#include "Tester/UpdateTests.hpp"

// main


int main(int argc, char* argv[])
{
int           c;
int stop = 0;

// Creating config instance and setting project type
XMLConfig& config = XMLConfig::get_instance();
config.set_application(Application::STLA); 

tinyxml2::XMLElement* rootElement = config.get_config("NEA");

// Creating and configurating CAN instance
CAN* canInstance = CAN::getInstance();
canInstance->Config(rootElement, "STLA");

// Creating and configurating CanIsoTp instance
CanIsoTp* isotpInstance = CanIsoTp::getInstance(canInstance);
isotpInstance->Config(rootElement);

// Creating and configurating UDS instance
UDSonCAN* UdsInstance = UDSonCAN::getInstance(isotpInstance);
UdsInstance->Config(5);

// Creating Tester instance
Tester* TesterInstance = Tester::getInstance(UdsInstance);

while (stop == 0) {

    unsigned long n;
    INPUT_RECORD ir;

    ReadConsoleInput(GetStdHandle(STD_INPUT_HANDLE), &ir, 1, &n);

    if ((n == 1) && (ir.EventType == KEY_EVENT)) {

      if (ir.Event.KeyEvent.bKeyDown) {

        c = ir.Event.KeyEvent.uChar.AsciiChar;
        switch (c) {
          case 't': { // transmit a message

              uint8_t dfi = 0; // Example data format identifier
              uint32_t address = 0x12345678; // Example address
              
             // Starting the timer
             auto start = std::chrono::high_resolution_clock::now();

             // Calling update sequence
             TesterInstance->minimal_update(dfi, address);

             // Stopping the timer
             auto end = std::chrono::high_resolution_clock::now();

             // Calculating duration
             auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
             auto minutes = std::chrono::duration_cast<std::chrono::minutes>(duration);
             auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration - minutes);
             auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(duration - minutes - seconds);

             std::cout << "Processing Completed in "
             << minutes.count() << " mins "
             << seconds.count() << " secs "
             << milliseconds.count() << " millisecs.........."
             << std::endl;
             break;
          }
          case 'h': {
              printHelp();
              break;
          }
          case 'p': {
              parserCall();
              break;
          }
          case 27: { // end application
              stop = 1;
              break;
          }
          default: {
              break;
          }
          // end switch
        }
      }
    }
  }
}              // end main()