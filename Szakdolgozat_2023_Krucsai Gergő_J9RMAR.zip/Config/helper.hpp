#ifndef HELPER_HPP
#define HELPER_HPP

void printHelp();

#endif