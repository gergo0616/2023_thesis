#include <windows.h>
#include <iostream>
#include "helper.hpp"
#include "../include/libs/bin/vxlapi.h"
#include <iomanip>
#include <string>

using namespace std;

void printHelp() {
    cout << "---------------------------------\n";
    cout << "-----------FlashTool-------------\n";
    cout << "-Keyboard commands:              \n";
    cout << "  -t                 Transmit msg\n";
    cout << "  -p             Parse descriptor\n";
    cout << "  -h                         Help\n";
    cout << "  -ESC                       Exit\n";
    cout << "---------------------------------\n";
}

