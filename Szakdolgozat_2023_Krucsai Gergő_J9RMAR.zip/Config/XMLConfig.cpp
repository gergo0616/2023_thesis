#include "XMLConfig.hpp"
#include <iostream>
#include <cassert>


XMLConfig* XMLConfig::instance = nullptr;


XMLConfig::XMLConfig() {
    // For demonstration purposes, skipping the equivalent logic to find the xml path.
    const char* config_file_path = "C:/Users/KRG4BP/Desktop/Thesis/FlashTool/fcatesting/source/config.xml";

    tinyxml2::XMLError eResult = doc.LoadFile(config_file_path);
    if (eResult != tinyxml2::XML_SUCCESS) {
        std::cout << "Error loading XML file" << std::endl;
        throw std::runtime_error("Error loading XML file");
    }

    // Set to an invalid application type by default.
    application = static_cast<Application>(-1);
}

// Define the get_instance function
XMLConfig& XMLConfig::get_instance() {
    if (!instance) {
        instance = new XMLConfig();
    }
    return *instance;
}

// Define the set_application function
void XMLConfig::set_application(Application app) {
    application = app;
}

// Define the get_config function
tinyxml2::XMLElement* XMLConfig::get_config(const std::string& variant) {
    if (application == static_cast<Application>(-1)) {
        std::cout << "Error: Application type not set." << std::endl;
        throw std::runtime_error("Application type first must be set.");
    }

    if (application == Application::FCA) {
        tinyxml2::XMLElement* foundElem = findElement(doc.RootElement(), "fca_config");
        if (foundElem) {
            return foundElem;
        }
    }
    else if (application == Application::STLA) {
        if (variant == "NEA") {
            tinyxml2::XMLElement* foundElem = findElement(doc.RootElement(), "stla_nea_config");
            if (foundElem) {
                return foundElem;
            }
        }
        else if (variant == "AEE") {
            tinyxml2::XMLElement* foundElem = findElement(doc.RootElement(), "stla_aee_config");
            if (foundElem) {
                return foundElem;
            }
        }
        else {
            std::cout << "Error: Wrong variant specified." << std::endl;
            throw std::runtime_error("Wrong variant! There is no config for the given variant! Please use NEA or AEE variant.");
        }
    }

    return nullptr;
}

tinyxml2::XMLElement* XMLConfig::findElement(tinyxml2::XMLElement* root, const char* tagName) {
    if (!root) {
        return nullptr;
    }
    
    if (std::strcmp(root->Value(), tagName) == 0) {
        return root;
    }

    for (tinyxml2::XMLElement* elem = root->FirstChildElement(); elem != nullptr; elem = elem->NextSiblingElement()) {
        tinyxml2::XMLElement* found = findElement(elem, tagName);
        if (found) {
            return found;
        }
    }
    return nullptr;
}

void XMLConfig::extractCanParams(tinyxml2::XMLElement* config, int& arbitration_id, tinyxml2::XMLElement*& can_params_element, bool& can_fd) {
    if (!config) return;

    // Use findElement to find the 'arbitration_id' element at any depth
    tinyxml2::XMLElement* arbitrationElem = findElement(config, "arbitration_id");
    if (arbitrationElem) {
        arbitration_id = std::stoi(arbitrationElem->GetText());
    }

    // Use findElement to find the 'can_params' element at any depth
    can_params_element = findElement(config, "can_params");
    if (can_params_element) {
        // Use findElement to find the 'can_fd' element at any depth within 'can_params'
        tinyxml2::XMLElement* canFdElem = findElement(can_params_element, "fd");
        if (canFdElem) {
            const char* str_can_fd = canFdElem->GetText();
            can_fd = checkAndConvertToBool(str_can_fd);
        }
    }
}

void XMLConfig::extractChannel(tinyxml2::XMLElement* config, int& channel){
    tinyxml2::XMLElement* channelElem = XMLConfig::findElement(config, "channel");
    if (channelElem) {
        const char* channelValue = channelElem->GetText();
        if (channelValue) {
            try {
                channel = std::stoi(channelValue);
                std::cout << "Extracted channel value: " << channel << std::endl;  // Using 'channel' instead of 'channelValue'
            } catch (const std::exception& e) {
                std::cerr << "Error converting 'channel' value to integer: " << e.what() << std::endl;
            }
        }
    } else {
        std::cerr << "Error: 'channel' element not found!" << std::endl;
    }
}

void XMLConfig::extractAppName(tinyxml2::XMLElement* config, char app_name[], std::size_t app_name_length) {
    tinyxml2::XMLElement* appElement = XMLConfig::findElement(config, "app_name");
    if (appElement) {
        const char* extractedAppName = appElement->GetText();
        if (extractedAppName) {
            if (std::strlen(extractedAppName) < app_name_length) {
                std::strcpy(app_name, extractedAppName);
                std::cout << "Extracted app_name value: " << app_name << std::endl;
            } else {
                std::cerr << "Error: Extracted app_name value is too long!" << std::endl;
            }
        } else {
            std::cerr << "Error: 'app_name' element is empty!" << std::endl;
        }
    } else {
        std::cerr << "Error: 'app_name' element not found!" << std::endl;
    }
}

void XMLConfig::extractAddressInfoFromXML(tinyxml2::XMLElement* element, int& addressingMode, uint32_t& txid, uint32_t& rxid) {
    if (!element) {
        throw std::invalid_argument("XMLElement pointer is null");
    }
    // Finding network_layer element
    tinyxml2::XMLElement* networkLayerElement = XMLConfig::findElement(element, "network_layer");
    if (!networkLayerElement) {
        throw std::runtime_error("network_layer element not found");
    }


    // Extract addressing mode
    tinyxml2::XMLElement* modeElement = networkLayerElement->FirstChildElement("addressing_mode");
    if (modeElement) {
        std::string modeText = modeElement->GetText();
        addressingMode = std::stoi(modeText);
    }

    // Extract txid
    tinyxml2::XMLElement* txidElement = networkLayerElement->FirstChildElement("txid");
    if (txidElement) {
        std::string txidText = txidElement->GetText();
        txid = std::stoul(txidText, nullptr, 16); // Assuming IDs are in hex
    }

    // Extract rxid
    tinyxml2::XMLElement* rxidElement = networkLayerElement ->FirstChildElement("rxid");
    if (rxidElement) {
        std::string rxidText = rxidElement->GetText();
        rxid = std::stoul(rxidText, nullptr, 16); // Assuming IDs are in hex
    }

}

bool XMLConfig::checkAndConvertToBool(const char* value) {
    if (value) {
        std::string strValue(value);
        return (strValue == "True" || strValue == "true");
    }
    return false;
}
