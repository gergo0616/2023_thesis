#pragma once

enum class Application {
    NONE,
    FCA,
    STLA,
};