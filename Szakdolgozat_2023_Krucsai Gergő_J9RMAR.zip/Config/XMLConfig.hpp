#ifndef XMLCONFIG_H
#define XMLCONFIG_H

#include <string>
#include <stdexcept>
#include "..\build\_deps\tinyxml2-src\tinyxml2.h"
#include "ApplicationEnum.hpp"
#include <tuple>

class XMLConfig {
private:
    // Private members and methods
    tinyxml2::XMLDocument doc;
    Application application;
    static XMLConfig* instance;

    // Private helper methods
    static tinyxml2::XMLElement* findElement(tinyxml2::XMLElement* root, const char* tagName);
    void extractCanParams(tinyxml2::XMLElement* config, int& arbitration_id, tinyxml2::XMLElement*& can_params_element, bool& can_fd);
    void extractChannel(tinyxml2::XMLElement* config, int& channel);
    void extractAppName(tinyxml2::XMLElement* config, char app_name[], std::size_t app_name_length);
    void extractAddressInfoFromXML(tinyxml2::XMLElement* element, int& addressingMode, uint32_t& txid, uint32_t& rxid);
    bool checkAndConvertToBool(const char* value);

public:
    // Constructor
    XMLConfig();

    // Delete copy constructor and copy assignment operator for singleton pattern
    XMLConfig(const XMLConfig&) = delete;
    XMLConfig& operator=(const XMLConfig&) = delete;

    // Public interface methods
    static XMLConfig& get_instance();
    void set_application(Application app);
    tinyxml2::XMLElement* get_config(const std::string& variant = "");
};

#endif // XMLCONFIG_H
