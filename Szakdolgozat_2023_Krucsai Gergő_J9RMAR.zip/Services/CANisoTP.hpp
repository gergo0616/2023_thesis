#ifndef CAN_ISO_TP_HPP
#define CAN_ISO_TP_HPP

#include <vector>
#include "CAN.hpp"
#include "isoTpHandler.hpp" // Make sure the file name is correct
#include <optional>

class CanIsoTp {
private:
    // Singleton instance
    static CanIsoTp* instance;

    // Private member variables
    CAN* can; // Pointer to CAN layer instance
    IsoTpHandler isotpHandler; // Handler for ISO-TP protocol
    int addressingMode;
    uint32_t rxId;
    uint32_t txId;
    bool can_fd;

    // Private constructor
    explicit CanIsoTp(CAN* can);

    // Private methods
    void createAddressFromConfig(int addressingMode, int txid, int rxid);
    void sendFlowControlFrame();

public:
    // Singleton access method
    static CanIsoTp* getInstance(CAN* can);

    // Public interface methods
    void Config(tinyxml2::XMLElement* rootElement);
    void send(const std::vector<uint8_t>& payload);
    std::pair<bool, std::vector<uint8_t>> waitForIsoTpResp(int timeoutSeconds);

    // Getters for internal state and properties
    CAN* getCANInstance() const;
    int getRxId() const;
    bool isCanFdSupported() const;
};

#endif // CAN_ISO_TP_HPP
