#include "CANBus.hpp"
#include <iostream>

#define RX_QUEUE_SIZE_FD           16384    // driver queue size for CAN-FD Rx events
#define RX_QUEUE_SIZE              4096     // internal driver queue size in CAN events

#include "../Communication/transmission.hpp"

// global variables
extern XLaccess g_xlChannelMask;
extern XLportHandle g_xlPortHandle;

CANBus::CANBus(int& channel, char* app_name, bool& can_fd) {
    XLstatus status;
    unsigned int xlChannel = 0;

    try {
        status = initDriver(&g_xlChannelMask, &xlChannel, app_name, can_fd);
    } catch (const std::exception& e) {
        std::cerr << "Exception occurred: " << e.what() << std::endl;
    }
}

CANBus::~CANBus() {
    shutdown();
}


std::pair<size_t, size_t> CANBus::send(const std::vector<uint8_t>& data, uint32_t arbitration_id, bool is_extended_id, bool can_fd, bool bitrate_switch) {
    XLstatus status;
    try {
        status = transmit(arbitration_id, g_xlChannelMask, data);

    } catch (const std::exception& e) {
        std::cerr << "Exception occurred: " << e.what() << std::endl;
    }
    return std::make_pair(sizeof(uint32_t) + data.size(), data.size());
}

XLcanRxEvent CANBus::receive(int timeoutInSeconds) {
    try {
        // Attempt to call the receive function from transmission.cpp
        return reception(timeoutInSeconds);
    } catch (const std::exception& e) {
        // Handle any exceptions that occur
        std::cerr << "Exception occurred during CAN reception: " << e.what() << std::endl;
        // Return an empty XLcanRxEvent object or a custom error object
        return XLcanRxEvent{};
    }
}


void CANBus::shutdown() {
        // Deactivate the channel
        xlDeactivateChannel(g_xlPortHandle, g_xlChannelMask);

        // Close the port
        xlClosePort(g_xlPortHandle);
    }