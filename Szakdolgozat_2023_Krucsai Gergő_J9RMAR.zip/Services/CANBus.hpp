#ifndef CAN_BUS_HPP
#define CAN_BUS_HPP

#include "../include/libs/bin/vxlapi.h"
#include <map>
#include <vector>
//#include "../Services/CANMessage.hpp"
#include <chrono>

#include "..\build\_deps\tinyxml2-src\tinyxml2.h"

class CANBus {
public:
    // Constructors and destructors
    CANBus(int& channel, char* app_name, bool& fd);
    ~CANBus();

    // Public interface for CAN bus operations
    std::pair<size_t, size_t> send(const std::vector<uint8_t>& data, uint32_t arbitration_id, bool is_extended_id, bool can_fd, bool bitrate_switch);
    XLcanRxEvent receive(int timeoutInSeconds);
    void shutdown();

private:
    // Member variables for CAN bus configuration and state
    XLportHandle portHandle = XL_INVALID_PORTHANDLE;
    XLaccess channelMask = 0;
    XLaccess permissionMask = 0;

};

#endif // CAN_BUS_HPP