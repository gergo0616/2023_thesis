#ifndef ISOTPHANDLER_HPP
#define ISOTPHANDLER_HPP

#include <vector>
#include <queue>
#include <optional>
#include "CAN.hpp"

// Struct to hold flow control information
struct FlowControlInfo {
    uint8_t blockSize;
    uint8_t separationTime;

    FlowControlInfo(uint8_t bs, uint8_t st) : blockSize(bs), separationTime(st) {}
};

class IsoTpHandler {
private:
    // Member variables for transmission state
    enum class TxState {
        Idle,
        TransmitSingleFrame,
        TransmitFirstFrame,
        WaitFlowControl,
        TransmitConsecutiveFrame,
        Finished
    };
    TxState txState;
    std::vector<uint8_t> currentPayload;
    size_t offset;
    size_t remaining;
    uint8_t sequenceNumber;

    // Member variables for reception state
    enum class RxState {
        Idle,
        WaitSingleFrame,
        WaitFirstFrame,
        WaitConsecutiveFrame,
        SendFlowControl,
        Finished
    };
    RxState rxState;
    std::vector<uint8_t> isoTpMessage; // Store the currently assembling ISO-TP message
    size_t expectedMessageSize;        // Expected size of the complete ISO-TP message
    std::queue<std::vector<uint8_t>> rxQueue;
    XLcanRxEvent latestCanFrame;
    bool newFrameReceived;

    // CAN interface
    CAN* can;

    // Private methods for transmission
    void initializeTransmission(const std::vector<uint8_t>& payload);
    void processStateMachine();
    void sendSingleFrame(const std::vector<uint8_t>& payload);
    void sendFirstFrame();
    void sendConsecutiveFrames();
    std::optional<FlowControlInfo> waitForCTS(unsigned int loopTimeout);

    // Private methods for reception
    void processReceivedCanFrame(const XLcanRxEvent& canFrame);
    void receiveSingleFrame();
    void receiveFirstFrame();
    void receiveConsecutiveFrame();
    bool isMessageComplete();

public:
    // Constructor
    explicit IsoTpHandler(CAN* can);

    // Public methods for transmission and reception
    void handleTransmission(const std::vector<uint8_t>& payload);
    std::optional<std::vector<uint8_t>> recv();
    std::vector<uint8_t> receiveIsoTpMessage(int timeoutSeconds);
};

#endif // ISOTPHANDLER_HPP
