#include "CanIsoTp.hpp"
#include <stdexcept>
#include <iostream>

CanIsoTp* CanIsoTp::instance = nullptr;

CanIsoTp::CanIsoTp(CAN* can) : can(can), isotpHandler(can) {
    if (!can) {
        throw std::invalid_argument("YourCanLayerClass pointer cannot be null");
    }
}

CanIsoTp* CanIsoTp::getInstance(CAN* can) {
    if (instance == nullptr) {
        instance = new CanIsoTp(can);
    }
    return instance;
}

CAN* CanIsoTp::getCANInstance() const {
    return this->can;
}

void CanIsoTp::createAddressFromConfig(int addressingMode, int txid, int rxid) {
    switch (addressingMode) {
        case 0:     //So when the addressing mode is set to 0 it means that it is looking for Normal11bits
                    //Address in this case only these 2 parameters has to be set in the constructor
            this->rxId = rxid;
            this->txId = txid;
            break;
        default:
            // Handle unknown addressing mode
            throw std::invalid_argument("Unknown addressing mode");
    }

}

void CanIsoTp::Config(tinyxml2::XMLElement* rootElement){
    XMLConfig xmlConfigObj;
    xmlConfigObj.extractAddressInfoFromXML(rootElement, this->addressingMode, this->txId, this->rxId);
    
    // Using addressing logic with createAdressFormConfig method
    createAddressFromConfig(this->addressingMode, this->txId, this->rxId);

    this->can_fd = can->isFdSupported();
}

void CanIsoTp::send(const std::vector<uint8_t>& payload) {
    // Pass the payload to IsoTpHandler for processing
    isotpHandler.handleTransmission(payload);
}

int CanIsoTp::getRxId() const {
    return rxId;
}

bool CanIsoTp::isCanFdSupported() const {
    return can->isFdSupported();
}