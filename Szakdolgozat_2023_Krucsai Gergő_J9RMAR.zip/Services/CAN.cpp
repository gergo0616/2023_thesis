#include "CAN.hpp"
#include <stdexcept>
#include <map>
#include "../include/libs/bin/vxlapi.h"
//#include "../Config/CANBus.hpp"
#include <iostream>




// Initialize the static member
CAN* CAN::instance = nullptr;

CAN::CAN()
    : bus(nullptr),
      can_fd(false),
      sumMsgLenWithAll(0),
      sumMsgLenOnlyData(0),
      can_params_element(nullptr),
      arbitration_id(0),
      project_name(""),
      channel(0),
      xlPortHandle(XL_ERR_INVALID_HANDLE),
      xlChannelMask(0)
{
    if (instance != nullptr) {
        throw std::runtime_error("CAN class is a singleton!");
    }
    instance = this;
}

CAN* CAN::getInstance() {
    if (!instance) {
        instance = new CAN();
    }
    return instance;
}

void CAN::Config(tinyxml2::XMLElement* projectConfig, const std::string& project_name) {
    if (!projectConfig) {
        std::cout << "Provided projectConfig is null." << std::endl;
        return;
    }
    XMLConfig xmlConfigObj;

    xmlConfigObj.extractCanParams(projectConfig, this->arbitration_id, this->can_params_element, this->can_fd);

    if (!can_params_element) {
        std::cout << "can_params not found in provided XML." << std::endl;
    }

    if (!arbitration_id) {
        std::cout << "Arbitration ID is  not set: " << arbitration_id << std::endl;
    }
    bus = new CANBus(this->channel, this->app_name, this->can_fd);
    this->project_name = project_name;
    std::cout << "Project name set as: " << this->project_name << std::endl;

}

void CAN::send(const std::vector<uint8_t>& data, uint32_t arbitration_id, XLaccess xlChanMaskTx) {
    bool bitrate_switch = false;
    if(true == this->can_fd){
        bitrate_switch = true;
    }
    else{
        bitrate_switch = false;
    }

    // Printing data
    std::cout << "Data to send: ";
        for (auto byte : data) {
            std::cout << std::hex << static_cast<int>(byte) << " ";
        }
        std::cout << std::dec << "\n";

    bool is_extended_id = false;
    auto [messageTotalSize, messageDataSize] = bus->send(data, arbitration_id, is_extended_id, can_fd, bitrate_switch);
    this->sumMsgLenWithAll += messageTotalSize;
    this->sumMsgLenOnlyData += messageDataSize;
}

XLcanRxEvent CAN::receive(int timeout) {
    return bus->receive(timeout);
}

std::vector<uint8_t> CAN::getData(const XLcanRxEvent& event) {
        std::vector<uint8_t> data;

        if (event.tag == XL_CAN_EV_TAG_RX_OK) {
            // Extracting the data from the canRxOkMsg member of the tagData union
            const XL_CAN_EV_RX_MSG& canMsg = event.tagData.canRxOkMsg;
            data.assign(canMsg.data, canMsg.data + canMsg.dlc);
        }

        return data;
    }

void CAN::shutdown() {
    bus->shutdown();
}

    // Getter for sumMsgLenWithAll
size_t CAN::getSumMsgLenWithAll() const {
    return sumMsgLenWithAll;
}

    // Getter for sumMsgLenOnlyData
size_t CAN::getSumMsgLenOnlyData() const {
    return sumMsgLenOnlyData;
}
    // Getter for XlChannelMask
XLaccess CAN::getXlChannelMask() const { return xlChannelMask; }

    // Getter for ArbitrationId
int CAN::getArbitrationId() const { return arbitration_id; }

bool CAN::isFdSupported() const { return can_fd; }

std::string CAN::getProjectName() const { return project_name; }



CAN::~CAN() {
    // Destructor body (clean-ups if needed)
}
