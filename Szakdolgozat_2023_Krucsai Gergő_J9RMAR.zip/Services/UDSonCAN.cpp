#include "UDSonCAN.hpp"
#include <iostream>
#include <thread>
#include <cmath>
// Include other necessary headers

UDSonCAN* UDSonCAN::instance = nullptr;

UDSonCAN::UDSonCAN(CanIsoTp* canisotp)
    : canisotp(canisotp), rpTimeout(0), rxid(0), can_fd(false) {
    instance = this;

    // If CanIsoTp contains information about rxid and can_fd, extract and set them here
    // if (canisotp) {
    //     conn = canisotp->getCANInstance(); // Assuming getCANInstance() returns a pointer to the CAN instance
    //     rxid = conn->getRxId();            // Assuming getRxId() returns the RxID
    //     can_fd = conn->isCanFdSupported(); // Assuming isCanFdSupported() checks CAN FD support
    // }
}

UDSonCAN::~UDSonCAN() {
    // Clean up resources if needed
}

UDSonCAN* UDSonCAN::getInstance(CanIsoTp* canisotp) {
    if (instance == nullptr) {
        instance = new UDSonCAN(canisotp);
    }
    return instance;
}

void UDSonCAN::Config(int rpTimeout) {
    
    this->rpTimeout = rpTimeout;
    this->can = canisotp->getCANInstance();
    this->projectName = can->getProjectName();
    this->can_fd = canisotp->isCanFdSupported();
    this->rxid = canisotp->getRxId();

    // Additional configuration
}

std::pair<bool, std::vector<uint8_t>> UDSonCAN::sendUdsMessage(const std::vector<uint8_t>& udsData, bool waitForResponse) {
    if (projectName == "STLA") {
        size_t size = udsData.size();
        size_t raw_data_size = this->can_fd ? 62 : 7;

        std::vector<uint8_t> can_data;
        if (size <= raw_data_size) {
            // Prepend the size of the UDS data
            can_data.push_back(static_cast<uint8_t>(size / 256));
            can_data.push_back(static_cast<uint8_t>(size % 256));
            can_data.insert(can_data.end(), udsData.begin(), udsData.end());

            // If size is small, adjust the data format to exclude the first byte
            if (size <= 7) {
                canisotp->send(std::vector<uint8_t>(can_data.begin() + 1, can_data.end()));
            } else {
                canisotp->send(can_data);
            }
        } else {
            // For larger data, send it directly as ISO-TP frames are meant to handle multi-frame messages
            canisotp->send(udsData);
        }
    }

    if (waitForResponse) {
        return waitForUdsResp(1);
    }

    return {false, std::vector<uint8_t>()}; // No response expected
}

std::pair<bool, std::vector<uint8_t>> UDSonCAN::waitForUdsResp(int loopTimeoutSeconds) {
    using namespace std::chrono;
    auto wait_until = steady_clock::now() + seconds(loopTimeoutSeconds);
    bool response = false;
    std::vector<uint8_t> response_data;

    std::cout << "Waiting for UDS response..." << std::endl;

    while (steady_clock::now() < wait_until) {
        auto receivedFrame = can->receive(loopTimeoutSeconds);
        
        if (receivedFrame.tag == XL_CAN_EV_TAG_RX_OK) {
            //std::cout << "Received CAN frame with ID: " << std::hex << receivedFrame.tagData.canRxOkMsg.canId << std::endl;

            if (receivedFrame.tagData.canRxOkMsg.canId == 2147485281/*rxid*/) { // Target's id hardcoded
                // Processing logic for the received frame
                auto highNibble = receivedFrame.tagData.canRxOkMsg.data[0] >> 4;

                if (receivedFrame.tagData.canRxOkMsg.dlc > 7 && highNibble == 1) { // First frame of multi-frame
                    std::cout << "Processing first frame of multi-frame message." << std::endl;

                    size_t lenCounter = ((receivedFrame.tagData.canRxOkMsg.data[0] & 0x0F) << 8) + receivedFrame.tagData.canRxOkMsg.data[1];
                    response_data.insert(response_data.end(), receivedFrame.tagData.canRxOkMsg.data + 2, receivedFrame.tagData.canRxOkMsg.data + receivedFrame.tagData.canRxOkMsg.dlc);
                    lenCounter -= response_data.size();


                } else {
                    std::cout << "Processing single frame or last frame of multi-frame message." << std::endl;
                    response_data.insert(response_data.end(), receivedFrame.tagData.canRxOkMsg.data, receivedFrame.tagData.canRxOkMsg.data + receivedFrame.tagData.canRxOkMsg.dlc);
                    response = true;
                    std::cout << "UDS response received" << std::endl;
                }
                break; // Break the loop once the message is processed
            }
        }
    }

    if (!response) {
        std::cout << "No response received or response incomplete within timeout period." << std::endl;
    }

    return {response, response_data};
}

void UDSonCAN::sleepForMilliseconds(int milliseconds) {
    auto start = std::chrono::high_resolution_clock::now();
    auto end = start + std::chrono::milliseconds(milliseconds);
    while (std::chrono::high_resolution_clock::now() < end) {
        // Busy-waiting
    }
}

std::pair<bool, std::vector<uint8_t>> UDSonCAN::transferData(uint8_t sequenceNumber, const std::vector<uint8_t>& data) {
    std::cout << "Sending transfer_data" << std::endl;

    // Construct the UDS data with the 'transfer data' SID and sequence number
    std::vector<uint8_t> udsData;
    udsData.push_back(0x36); // 'transfer data' Service ID
    udsData.push_back(sequenceNumber);
    udsData.insert(udsData.end(), data.begin(), data.end());

    // Log the UDS data
    std::cout << "UDS Data: ";
    for (auto byte : udsData) {
        std::cout << std::hex << static_cast<int>(byte) << " ";
    }
    std::cout << std::endl;

    // Send the UDS message and return the result
    return sendUdsMessage(udsData, true);
}

std::pair<bool, std::vector<uint8_t>> UDSonCAN::requestDownload(uint8_t dfi, uint32_t address, const std::vector<uint8_t>& data) {
    std::cout << "Sending request_download" << std::endl;

    uint8_t alfid = 0x44; // addressAndLengthFormatIdentifier
    std::vector<uint8_t> udsData;
    udsData.push_back(0x34); // 'request download' Service ID
    udsData.push_back(dfi);
    udsData.push_back(alfid);

    // Append the address and length of the data
    for (int i = 3; i >= 0; --i) {
        udsData.push_back((address >> (i * 8)) & 0xFF);
    }
    uint32_t dataLength = data.size();
    for (int i = 3; i >= 0; --i) {
        udsData.push_back((dataLength >> (i * 8)) & 0xFF);
    }

    // Log the UDS data
    std::cout << "UDS Data: ";
    for (auto byte : udsData) {
        std::cout << std::hex << static_cast<int>(byte) << " ";
    }
    std::cout << std::endl;

    // Send the UDS message and return the result
    return sendUdsMessage(udsData, true);
}

std::pair<bool, std::vector<uint8_t>> UDSonCAN::requestTransferExit(const std::optional<std::vector<uint8_t>>& data) {
    std::cout << "Sending request_transfer_exit" << std::endl;

    // Construct the UDS data with 'request transfer exit' Service ID
    std::vector<uint8_t> udsData;

    // If additional data is provided, insert it before the service ID
    if (data.has_value()) {
        const auto& additionalData = data.value();
        udsData.insert(udsData.end(), additionalData.begin(), additionalData.end());
    }

    // Insert the 'request transfer exit' Service ID after the additional data
    udsData.push_back(0x37);

    // Log the UDS data
    std::cout << "UDS Data: ";
    for (auto byte : udsData) {
        std::cout << std::hex << static_cast<int>(byte) << " ";
    }
    std::cout << std::endl;

    // Send the UDS message and return the result
    return sendUdsMessage(udsData, true);
}




// Implement other methods following the structure of the Python class
