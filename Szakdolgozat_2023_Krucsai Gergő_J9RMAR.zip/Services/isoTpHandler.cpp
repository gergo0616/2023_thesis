#include "IsoTpHandler.hpp"
#include <iostream>

constexpr size_t MAX_FRAME_SIZE = 64;
constexpr uint8_t FIRST_FRAME_N_PCI = 0x10;
constexpr uint8_t CONSECUTIVE_FRAME_N_PCI = 0x20;
constexpr uint8_t FLOW_CONTROL_FRAME_N_PCI = 0x30;
constexpr uint8_t CONTINUE_TO_SEND = 0x00;
//constexpr uint8_t BLOCK_SIZE = 0x05;  // Number of frames before waiting for another flow control frame
constexpr uint8_t ST_MIN = 0x00;      // Minimum separation time in milliseconds

IsoTpHandler::IsoTpHandler(CAN* can) : can(can), txState(TxState::Idle), rxState(RxState::Idle) {}

void IsoTpHandler::handleTransmission(const std::vector<uint8_t>& payload) {
    initializeTransmission(payload);
    while (txState != TxState::Finished) {
        processStateMachine();
    }
}

void IsoTpHandler::initializeTransmission(const std::vector<uint8_t>& payload) {
    currentPayload = payload;
    offset = 0;
    remaining = payload.size();
    sequenceNumber = 1;
    txState = payload.size() <= (MAX_FRAME_SIZE - 2) ? TxState::TransmitSingleFrame : TxState::TransmitFirstFrame;
    std::cout << "Initializing Transmission." << std::endl;
}

void IsoTpHandler::processStateMachine() {
    switch (txState) {
        case TxState::Idle:
            // Default state
            break;
        case TxState::TransmitSingleFrame:
            sendSingleFrame(currentPayload);
            break;
        case TxState::TransmitFirstFrame:
            sendFirstFrame();
            break;
        case TxState::WaitFlowControl:
            // Handle wait for flow control state
            waitForCTS(1000);
            break;
        case TxState::TransmitConsecutiveFrame:
            sendConsecutiveFrames();
            break;
        case TxState::Finished:
            // Done state
            break;
    }

}

////////////////////////////////////////////////////////////////////////////////////////////
// TRANSCIEVER FUNCTIONS

void IsoTpHandler::sendSingleFrame(const std::vector<uint8_t>& payload) {
    std::vector<uint8_t> frame = payload;
    can->send(frame, can->getArbitrationId(), can->getXlChannelMask());
    txState = TxState::Finished;
}

void IsoTpHandler::sendFirstFrame() {
    std::vector<uint8_t> frame;
    size_t firstFramePayloadLength = std::min(remaining, MAX_FRAME_SIZE - 6);
    frame.push_back(FIRST_FRAME_N_PCI | ((currentPayload.size() >> 8) & 0x0F));
    frame.push_back(currentPayload.size() & 0xFF);
    frame.insert(frame.end(), currentPayload.begin(), currentPayload.begin() + firstFramePayloadLength);
    can->send(frame, can->getArbitrationId(), can->getXlChannelMask());
    remaining -= firstFramePayloadLength;
    offset += firstFramePayloadLength;
    txState = TxState::WaitFlowControl;
}

void IsoTpHandler::sendConsecutiveFrames() {
    while (remaining > 0) {
        std::vector<uint8_t> frame;
        size_t consecutiveFramePayloadLength = std::min(remaining, MAX_FRAME_SIZE - 2);
        frame.push_back(CONSECUTIVE_FRAME_N_PCI | (sequenceNumber & 0x0F));
        frame.insert(frame.end(), currentPayload.begin() + offset, currentPayload.begin() + offset + consecutiveFramePayloadLength);
        can->send(frame, can->getArbitrationId(), can->getXlChannelMask());
        remaining -= consecutiveFramePayloadLength;
        offset += consecutiveFramePayloadLength;
        sequenceNumber = (sequenceNumber + 1) % 16;
        // Consider flow control logic here if needed
    }
    txState = TxState::Finished;
}

std::optional<FlowControlInfo> IsoTpHandler::waitForCTS(unsigned int loopTimeout) {
    //temporarly skip flow control
    txState = IsoTpHandler::TxState::TransmitConsecutiveFrame; // Set state after sending

    // std::cout << "waiting for flow control frame" << std::endl;
    // using namespace std::chrono;
    // auto waitUntil = steady_clock::now() + milliseconds(loopTimeout);
    // while (steady_clock::now() < waitUntil) {

    //     XLcanRxEvent receivedFrame = can->receive(loopTimeout);

    //     // Check for a valid Flow Control Frame
    //     if (receivedFrame.tag == XL_CAN_EV_TAG_RX_OK) {
    //         XL_CAN_EV_RX_MSG& canMsg = receivedFrame.tagData.canRxOkMsg;
    //         if (canMsg.data[0] == FLOW_CONTROL_FRAME_N_PCI && canMsg.dlc == 3) {
    //             std::cout << "CTS received\n";
    //             txState = IsoTpHandler::TxState::TransmitConsecutiveFrame; // Set state after sending
    //             return FlowControlInfo(canMsg.data[1], canMsg.data[2]);
    //         }
    //     }
    // }

    std::cerr << "CTS timeout or no valid frame received\n";
    return std::nullopt;
}


////////////////////////////////////////////////////////////////////////////////////////////
// RECEIVER FUNCTIONS


// void IsoTpHandler::receiveSingleFrame() {
//         // Extract and process data from latestCanFrame as a single frame
//         std::vector<uint8_t> frameData(latestCanFrame.tagData.canRxOkMsg.data + 1, 
//                                        latestCanFrame.tagData.canRxOkMsg.data + latestCanFrame.tagData.canRxOkMsg.dlc);
//         rxQueue.push(frameData);
//         rxState = RxState::Idle;
//     }

// void IsoTpHandler::receiveFirstFrame() {
//     std::cout << "Processing Received First Frame" << std::endl;
//     int totalSize = ((latestCanFrame.tagData.canRxOkMsg.data[0] & 0x0F) << 8) | latestCanFrame.tagData.canRxOkMsg.data[1];
//     expectedMessageSize = totalSize;
//     std::cout << "Expected Message Size Set: " << expectedMessageSize << std::endl;

//     std::vector<uint8_t> frameData(latestCanFrame.tagData.canRxOkMsg.data + 2, latestCanFrame.tagData.canRxOkMsg.data + latestCanFrame.tagData.canRxOkMsg.dlc);
//     isoTpMessage.clear();
//     isoTpMessage.insert(isoTpMessage.end(), frameData.begin(), frameData.end());
//     rxState = RxState::WaitConsecutiveFrame;
// }

// void IsoTpHandler::receiveConsecutiveFrame() {
//     std::cout << "Processing Received Consecutive Frame" << std::endl;

//     if (rxState == RxState::WaitConsecutiveFrame) {
//         std::vector<uint8_t> frameData(latestCanFrame.tagData.canRxOkMsg.data + 1, latestCanFrame.tagData.canRxOkMsg.data + latestCanFrame.tagData.canRxOkMsg.dlc);

//         std::cout << "Consecutive Frame Data Size: " << frameData.size() << std::endl;
//         isoTpMessage.insert(isoTpMessage.end(), frameData.begin(), frameData.end());

//         std::cout << "Current ISO-TP Message Size: " << isoTpMessage.size() << std::endl;
//         std::cout << "Expected Message Size: " << expectedMessageSize << std::endl;

//         if (isoTpMessage.size() >= expectedMessageSize) {
//             rxQueue.push(isoTpMessage);
//             isoTpMessage.clear();
//             rxState = RxState::Idle;
//             std::cout << "Consecutive Frame Processed, Message Complete" << std::endl;
//         }
//     }
// }


// // Switching from FirstFrame to ConsecutiveFrame state based on the received frame's first byte
// void IsoTpHandler::processReceivedCanFrame(const XLcanRxEvent& canFrame) {
//     std::cout << "Received CAN Frame with ID: " << std::hex << canFrame.tagData.canRxOkMsg.canId << std::endl;
//     uint8_t pciType = canFrame.tagData.canRxOkMsg.data[0] & 0xF0;
//     std::cout << "PCI Type: " << std::hex << static_cast<int>(pciType) << std::endl;

//         std::cout << "Raw Frame Received. ID: " << std::hex << canFrame.tagData.canRxOkMsg.canId << ", Data: ";
//             for (int i = 0; i < canFrame.tagData.canRxOkMsg.dlc; ++i) {
//                 std::cout << std::hex << static_cast<int>(canFrame.tagData.canRxOkMsg.data[i]) << " ";
//             }
//             std::cout << std::endl;


//     switch (pciType) {
//         case FIRST_FRAME_N_PCI:
//             std::cout << "Setting state to WaitFirstFrame" << std::endl;
//             rxState = RxState::WaitFirstFrame;
//             break;
//         case CONSECUTIVE_FRAME_N_PCI:
//             std::cout << "Setting state to WaitConsecutiveFrame" << std::endl;
//             rxState = RxState::WaitConsecutiveFrame;
//             break;
//         default:
//             std::cout << "Unhandled PCI Type" << std::endl;
//             break;
//     }
// }

// std::vector<uint8_t> IsoTpHandler::receiveIsoTpMessage(int timeoutSeconds) {
//     XLcanRxEvent canFrame;
//     auto startTime = std::chrono::high_resolution_clock::now();

//     while (std::chrono::duration_cast<std::chrono::seconds>(std::chrono::high_resolution_clock::now() - startTime).count() < timeoutSeconds) {
//         canFrame = can->receive(timeoutSeconds);

//         if (canFrame.tag == XL_CAN_EV_TAG_RX_OK) {
//             processReceivedCanFrame(canFrame);

//             if (isMessageComplete()) {
//                 std::cout << "ISO-TP Message is complete. Size: " << isoTpMessage.size() << std::endl;
//                 auto completeMessage = isoTpMessage;
//                 isoTpMessage.clear(); // Clear the buffer for next message
//                 return completeMessage; // Return the complete ISO-TP message
//             }
//         }
//     }

//     std::cout << "ISO-TP Message reception timeout or incomplete message." << std::endl;
//     return std::vector<uint8_t>(); // Return empty if timeout or incomplete
// }

// bool IsoTpHandler::isMessageComplete() {
//     std::cout << "Checking if ISO-TP Message is Complete. Current State: " << static_cast<int>(rxState) << std::endl;
//     if (rxState == RxState::Idle) {
//         return false; // No message is being received.
//     }

//     if (rxState == RxState::WaitSingleFrame) {
//         return true; // Single frame message completion
//     }

//     if (rxState == RxState::WaitFirstFrame || rxState == RxState::WaitConsecutiveFrame) {
//         if (!isoTpMessage.empty() && isoTpMessage.size() >= expectedMessageSize) {
//             return true; // Multi-frame message completion
//         }
//     }

//     return false;
// }


// Additional private methods and logic...


// Implement other private methods and logic as necessary...



