#ifndef UDSONCAN_HPP
#define UDSONCAN_HPP

#include "CanIsoTp.hpp"
#include <string>
#include <vector>
#include <optional>
#include "../Config/XMLConfig.hpp"

// Define additional constants and enums as required

class UDSonCAN {
public:
    // Constructor
    UDSonCAN(CanIsoTp* canisotp);

    // Destructor
    ~UDSonCAN();

    // Get instance method
    static UDSonCAN* getInstance(CanIsoTp* canisotp);

    // Other methods
    void Config(int rpTimeout);
    std::pair<bool, std::vector<uint8_t>> sendUdsMessage(const std::vector<uint8_t>& udsData, bool waitForResponse);
    std::pair<bool, std::vector<uint8_t>> waitForUdsResp(int loopTimeoutSeconds);
    bool waitForOutOfSeqMsg(unsigned int timeoutSeconds);
    void sleepForMilliseconds(int milliseconds);

    //UDS messages:
    std::pair<bool, std::vector<uint8_t>> transferData(uint8_t sequenceNumber, const std::vector<uint8_t>& data);
    std::pair<bool, std::vector<uint8_t>> requestDownload(uint8_t dfi, uint32_t address, const std::vector<uint8_t>& data);
    std::pair<bool, std::vector<uint8_t>> requestTransferExit(const std::optional<std::vector<uint8_t>>& data);

private:
    static UDSonCAN* instance;
    std::string projectName;

    CanIsoTp* canisotp; // Pointer to the CANisoTP instance
    CAN* can;          // Pointer to the CAN connection (assuming CAN is a class)
    int rpTimeout;      // Response pending timeout
    int rxid;           // Receiver ID
    bool can_fd;        // Flag to indicate CAN FD support

    UDSonCAN(const UDSonCAN&) = delete;
    UDSonCAN& operator=(const UDSonCAN&) = delete;
};

#endif // UDSONCAN_HPP
