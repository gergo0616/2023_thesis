#pragma once
#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include "../include/libs/bin/vxlapi.h"
#include <chrono>
#include <thread>
#include "..\build\_deps\tinyxml2-src\tinyxml2.h"

//#include "../Config/ValueTypeEnum.hpp"
#include "CANBus.hpp"
#include "../Config/XMLConfig.hpp"



class CAN {
private:
    // Singleton instance
    static CAN* instance;

    // CAN bus interface
    CANBus* bus;
    XLportHandle xlPortHandle;
    XLaccess xlChannelMask;

    // Configuration and state
    tinyxml2::XMLElement* can_params_element;
    int sumMsgLenWithAll;
    int sumMsgLenOnlyData;
    int channel;
    int arbitration_id;
    unsigned int messageCount;
    char app_name[XL_MAX_APPNAME+1];
    std::string project_name;

    // Private constructor for the Singleton pattern
    CAN();

    // Private helper methods
    void _mapAppConfig(tinyxml2::XMLElement*& can_params_element);

public:
    // Flag to indicate CAN FD support
    bool can_fd;

    // Deleted copy constructor and assignment operator for Singleton pattern
    CAN(const CAN&) = delete;
    CAN& operator=(const CAN&) = delete;

    // Destructor
    ~CAN();

    // Singleton instance access
    static CAN* getInstance();

    // Initialization and configuration
    XLstatus initDriver(XLaccess *pxlChannelMaskTx, unsigned int *pxlChannelIndex);
    void Config(tinyxml2::XMLElement* projectConfig, const std::string& project_name);

    // CAN bus operations
    void send(const std::vector<uint8_t>& data, uint32_t arbitration_id, XLaccess xlChanMaskTx);
    XLcanRxEvent receive(int timeout);
    std::vector<uint8_t> getData(const XLcanRxEvent& event);
    void shutdown();

    // Getters for internal state and properties
    size_t getSumMsgLenOnlyData() const;
    size_t getSumMsgLenWithAll() const;
    XLaccess getXlChannelMask() const;
    int getArbitrationId() const;
    bool isFdSupported() const;
    std::string getProjectName() const;
};