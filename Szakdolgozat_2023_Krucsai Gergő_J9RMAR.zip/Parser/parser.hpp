#ifndef PARSER_HPP
#define PARSER_HPP

#include <string>
#include <vector>
#include <map>
#include <optional>
#include <stdexcept>
#include "..\build\_deps\tinyxml2-src\tinyxml2.h"

// Forward declaration of tinyxml2 classes
namespace tinyxml2 {
    class XMLDocument;
    class XMLElement;
}

// FlashObject class definition
class FlashObject {
public:
    std::string dataid;
    std::string datafile;
    int start_address = 0;
    int uncompressed_size = 0;
    int dfi = 0;
    std::map<std::string, std::string> security;
    std::optional<int> logical_block_id;
    std::optional<std::string> flashdataid;

    FlashObject();
};

// Utility function declarations
void unzipPdx(const char* zip_filename, const char* output_folder);
void parserCall();
int ParseInt(const std::string& text);
int convert_types(const std::string& type_text, const std::string& value);
int get_swe_from_data_block_id(const std::string& text);
std::string getExtension(const std::string& filepath);
std::string getUnpackFolder(const std::string& filepath);
bool create_directory(const std::string& path);
std::string getDirectoryPath(const std::string& filepath);
std::string getStem(const std::string& filepath);
std::vector<FlashObject> parse_container(const std::string& container_path);
#endif