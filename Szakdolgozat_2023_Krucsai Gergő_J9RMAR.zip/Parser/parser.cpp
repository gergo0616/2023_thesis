#include <sstream>
#include <string>
#include <fstream>
#include "parser.hpp"
#include <iostream>
#include <cstdlib>
#include <vector>
#include <map>
#include <stdexcept>
#include <regex>
#include <variant>
#include <optional>

// External libraries
#include "..\build\_deps\tinyxml2-src\tinyxml2.h"
#include "..\build\_deps\miniz-src\miniz.h"


#ifdef _WIN32
#include <windows.h>
#else
#include <sys/stat.h>
#include <errno.h>
#endif

//Test function
int ParseInt(const std::string& text) {
    int value;
    std::istringstream iss(text);
    iss >> value;
    return value;
}

//Function to call the parser
void parserCall(){
    std::cout << "Insert the full path of the container:" << std::endl;
    std::string parser_path;
    std::cin >> parser_path;
    parse_container(parser_path);
}

//Default konstruktor default value
FlashObject::FlashObject() {
    dataid = "";
    datafile = "";
    start_address = 0;
    uncompressed_size = 0;
    flashdataid = "";
    dfi = 0;
    security.clear();
    logical_block_id.reset();
}

// Utility functions
int convert_types(const std::string& type_text, const std::string& value) {
    if (type_text == "A_UINT32" || type_text == "A_UINT16" || type_text == "A_UINT8") {
        return std::stoull(value);
    }
    throw std::runtime_error("Convert of " + type_text + " was not implemented.");
}

/*SWE number is not stored on the PDX file. In other case, datablocks have id, which is bigger than SWE number by 1.
This method parse and calculated the SWE number from this id.*/
int get_swe_from_data_block_id(const std::string& text) {
    std::regex re(".*DATABLOCK([0-9]+)\\.ID$");
    std::smatch match;
    if (std::regex_search(text, match, re) && match.size() > 1) {
        return std::stoi(match.str(1));
    }
    return 0;
}

std::string getExtension(const std::string& filepath) {
    // Find the last occurrence of '.' (dot) in the filepath
    size_t dotPos = filepath.rfind(".pdx");
    // Container_path -> Odx file, Unpack_folder -> Container folder
    std::string container_path;
    std::string unpack_folder = getUnpackFolder(filepath);
    // If .pdx is found
    if(dotPos != std::string::npos && dotPos < filepath.size() - 1) {
        // Return the substring from the dot to the end of the string
        unzipPdx(filepath.c_str(), unpack_folder.c_str());
        return container_path = unpack_folder + "\\unzipped_files" + "\\flash_cfg.odx";
    }
    else{
        return filepath;
    }
    // If dot not found, return an empty string
    return "";
}

std::string getUnpackFolder(const std::string& filepath) {
    // Find the position of the last backward slash in the filepath
    size_t slashPosBackward = filepath.rfind('\\');

    // Find the position of the last forward slash in the filepath
    size_t slashPosForward = filepath.rfind('/');
    size_t slashPos = slashPosForward;

    // If no forward slash was found, or a backward slash was found and is closer to the end of the string,
    // use the position of the backward slash
    if(slashPos == std::string::npos || (slashPosBackward != std::string::npos && slashPosBackward > slashPos)) {
        slashPos = slashPosBackward;
    }

    // If a slash was found, return the substring from the start of the string to the slash position
    // Removing the file name from the filepath, leaving the directory path
    if(slashPos != std::string::npos) {
        return filepath.substr(0, slashPos);
    }

    // If no slash was found, no directory path could be determined
    return "";
}

// Create directory to hold the uncompressed file
bool create_directory(const std::string& path) {
#ifdef _WIN32
    // Windows implementation
    if (CreateDirectory(path.c_str(), NULL) ||
        ERROR_ALREADY_EXISTS == GetLastError()) {
        return true;
    } else {
        return false;
    }
#else
    // POSIX implementation
    if (mkdir(path.c_str(), 0755) == 0 || errno == EEXIST) {
        return true;
    } else {
        return false;
    }
#endif
}


void unzipPdx(const char* zip_filename, const char* output_folder) {
    // Concatenate the output folder path with a new folder name to store unzipped files
    std::string unzip_dir = std::string(output_folder) + "/unzipped_files";

    // Try to create a new directory to store unzipped files and handle failure
    if (!create_directory(unzip_dir)) {
        std::cerr << "Failed to create directory: " << unzip_dir << std::endl;
        return;
    }

    // Declare and initialize a zip archive object
    mz_zip_archive zip_archive;
    memset(&zip_archive, 0, sizeof(zip_archive));

    // Initialize the ZIP archive reader and handle failure
    if (!mz_zip_reader_init_file(&zip_archive, zip_filename, 0)) {
        fprintf(stderr, "Failed to initialize ZIP archive: %s\n", zip_filename);
        return;
    }

    // Loop through each file in the ZIP archive
    for (mz_uint i = 0; i < mz_zip_reader_get_num_files(&zip_archive); i++) {
        // Declare a file stat object to store file information
        mz_zip_archive_file_stat file_stat;

        // Retrieve information about the current file and handle failure
        if (!mz_zip_reader_file_stat(&zip_archive, i, &file_stat)) {
            fprintf(stderr, "Failed to get information about file %d in the ZIP archive.\n", i);
            mz_zip_reader_end(&zip_archive);
            return;
        }

        // Declare and construct the output filename path
        char output_filename[1024];
        snprintf(output_filename, sizeof(output_filename), "%s/%s", unzip_dir.c_str(), file_stat.m_filename);

        // Extract the current file to the specified path and handle failure
        if (!mz_zip_reader_extract_to_file(&zip_archive, i, output_filename, 0)) {
            fprintf(stderr, "Failed to extract file: %s\n", file_stat.m_filename);
            mz_zip_reader_end(&zip_archive);
            return;
        }
    }

    // Clean up and close the ZIP archive reader
    mz_zip_reader_end(&zip_archive);
}


std::vector<FlashObject> parse_container(const std::string& container_path) {
    //Calling gitExtension to decide PDX or ODX
    std::string filePath = getExtension(container_path);

    //Creating file object
    std::ifstream file(filePath);

    // Existance check
    if (!file.good()) {
        std::cout << "File does not exist: " << filePath << std::endl;
        return {};
    }
    file.close();

    // Print filepath info
    std::cout << "Loading XML file from: " << filePath << std::endl;

    // Checking XML errors in the file
    tinyxml2::XMLDocument doc;
    tinyxml2::XMLError loadErr = doc.LoadFile(filePath.c_str());
    if (loadErr != tinyxml2::XML_SUCCESS) {
        std::cout << "Error loading XML file: " << loadErr << std::endl;
    return {};
    } else {
        std::cout << "XML file loaded successfully." << std::endl;
    }

    // Checking that the file has root element
    tinyxml2::XMLElement* root = doc.RootElement();
    if (!root) {
        std::cout << "Error: Root element is null" << std::endl;
    return {};
    } else {
    std::cout << "Root element obtained successfully." << std::endl;
	}

    //Defining main root elements to prevent iterating everytime
    tinyxml2::XMLElement* flash = root->FirstChildElement("FLASH");
    tinyxml2::XMLElement* ecuMems = flash ? flash->FirstChildElement("ECU-MEMS") : nullptr;
    tinyxml2::XMLElement* ecuMem = ecuMems ? ecuMems->FirstChildElement("ECU-MEM") : nullptr;
    tinyxml2::XMLElement* mem = ecuMem ? ecuMem->FirstChildElement("MEM") : nullptr;
    tinyxml2::XMLElement* sessions = mem ? mem->FirstChildElement("SESSIONS") : nullptr;
    tinyxml2::XMLElement* session = sessions ? sessions->FirstChildElement("SESSION") : nullptr;

    //Store ID-REF from DATABLOCK-REFS in references allowed
    std::vector<std::string> references_allowed;
    if (session) {
        tinyxml2::XMLElement* datablocksRef = session->FirstChildElement("DATABLOCK-REFS");
        if (datablocksRef) {
            for (tinyxml2::XMLElement* datablockRef = datablocksRef->FirstChildElement("DATABLOCK-REF"); datablockRef != nullptr; datablockRef = datablockRef->NextSiblingElement("DATABLOCK-REF")) {
                std::string ident = datablockRef->Attribute("ID-REF");
                references_allowed.push_back(ident);
            }
        }
    }

    tinyxml2::XMLElement* datablocks = mem ? mem->FirstChildElement("DATABLOCKS") : nullptr;

    //Check that the references_allowed ID-REFS matching the DATABLOCK's ID
    std::vector<FlashObject> flashContainer;
    if (datablocks) {
        for (tinyxml2::XMLElement* datablock = datablocks->FirstChildElement("DATABLOCK"); datablock != nullptr; datablock = datablock->NextSiblingElement("DATABLOCK")) {
            std::string id = datablock->Attribute("ID");
            if (std::find(references_allowed.begin(), references_allowed.end(), id) == references_allowed.end()) {
                continue;
            }

            //Defining values of the FlashObject's variables
            FlashObject obj;
            obj.dataid = id;
            obj.logical_block_id = get_swe_from_data_block_id(obj.dataid);
            obj.flashdataid =  datablock->FirstChildElement("SHORT-NAME")->NextSiblingElement("FLASHDATA-REF")->Attribute("ID-REF");

            //Defining value of dfi
            for (tinyxml2::XMLElement* flashdata = mem->FirstChildElement("FLASHDATAS")->FirstChildElement("FLASHDATA"); flashdata != nullptr; flashdata = flashdata->NextSiblingElement("FLASHDATA")) {
                if(flashdata->Attribute("ID") == obj.flashdataid){
                    obj.dfi = std::stoi(flashdata->FirstChildElement("SHORT-NAME")->NextSiblingElement("DATAFORMAT")->NextSiblingElement("ENCRYPT-COMPRESS-METHOD")->GetText());
                }
            }

            //Defining values of start_adress and uncompressed_size
            for (tinyxml2::XMLElement* segment = datablock->FirstChildElement("SEGMENTS")->FirstChildElement("SEGMENT"); segment != nullptr; segment = segment->NextSiblingElement("SEGMENTS")) {
                obj.start_address = std::stoi(segment->FirstChildElement("SHORT-NAME")->NextSiblingElement("SOURCE-START-ADDRESS")->GetText(), nullptr, 16);
                obj.uncompressed_size = std::stoi(segment->FirstChildElement("UNCOMPRESSED-SIZE")->GetText());
            }

            //Defining values of security_method and fw_checksum
            for (tinyxml2::XMLElement* security = datablock->FirstChildElement("SECURITYS")->FirstChildElement("SECURITY"); security != nullptr; security = security->NextSiblingElement("SECURITY")) {
                std::string security_method = security->FirstChildElement("SECURITY-METHOD")->GetText();
                tinyxml2::XMLElement* fw_checksum = security->FirstChildElement("FW-CHECKSUM");
                if (security_method == "CRC32") {
                    obj.security["CRC"] = std::to_string(convert_types(fw_checksum->Attribute("TYPE"), fw_checksum->GetText()));
                }
            }

            //Pusing the flashObject to the end of the flashContainer vector
            flashContainer.push_back(obj);
        }
    }

    int i = 0;
    if (mem) {
        std::vector<std::vector<std::string>> container;
        for (tinyxml2::XMLElement* flashdata = mem->FirstChildElement("FLASHDATAS")->FirstChildElement("FLASHDATA"); flashdata != nullptr; flashdata = flashdata->NextSiblingElement("FLASHDATA")) {
            
            //It searches flashContainer for a FlashObject with a matching flashdataid
            FlashObject* fobj_found = nullptr;
            for (auto& fobj : flashContainer) {
                const char* id = flashdata->Attribute("ID");
                if (id != nullptr && fobj.flashdataid.has_value() && fobj.flashdataid.value() == id) {
                    fobj_found = &fobj;
                    break;
                }
            }
            
            //Extracting DATAFILE's text content, and using this text content to update a FlashObject instance and the 2D string container.
            tinyxml2::XMLElement* datafileElem = flashdata->FirstChildElement("DATAFILE");
            if (datafileElem != nullptr) {
                const char* datafileText = datafileElem->GetText();
                if (datafileText != nullptr) {
                    fobj_found->datafile = container_path + "/" + datafileText; //change this after implementing PDX
                    // Ensure container has enough sub-vectors
                    if (i >= container.size()) container.resize(i + 1);
                    // Ensure the i-th sub-vector has at least 1 element
                    container[i].resize(1);
                    // Update the first element of this sub-vector with the datafile of the found FlashObject
                    container[i][0] = fobj_found->datafile;
                    std::cout << "Updated container[" << i << "][0] to: " << container[i][0] << std::endl;
                    i++;
                } else {
                    std::cout << "DATAFILE element is empty. Skipping." << std::endl;
                }
            } else {
                std::cout << "No DATAFILE element found. Skipping." << std::endl;
            }
        }
    }
    return flashContainer;
}