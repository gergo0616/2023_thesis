#include "../Services/UDSonCAN.hpp"
#include <memory>
#include <vector>

class Tester {
public:
    Tester(UDSonCAN* udsOnCan);

    static Tester* getInstance(UDSonCAN* udsOnCan);

    void minimal_update(uint8_t dfi, uint32_t address);

    void medium_update(uint8_t dfi, uint32_t address);

    std::vector<std::vector<uint8_t>> generateRandomDataBlocks(int numBlocks, int blockSize);

   void createHexFile(const std::string& filename, int numBlocks, int blockSize);

   std::vector<std::vector<uint8_t>> parseHexFile(const std::string& filename);

private:
    static Tester* instance;
    UDSonCAN* udsOnCan;
    std::vector<uint8_t> testData;
};