#include "UpdateTests.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

#include <fstream>  // For file streams
#include <iomanip>  // For std::setw and std::setfill
#include <sstream>  // For std::istringstream



Tester* Tester::instance = nullptr;

Tester::Tester(UDSonCAN* udsOnCan) : udsOnCan(udsOnCan) {}

Tester* Tester::getInstance(UDSonCAN* udsOnCan) {
    if (instance == nullptr) {
        instance = new Tester(udsOnCan);
    }
    return instance;
}

void Tester::minimal_update(uint8_t dfi, uint32_t address) {
    // Optionally set testData to a predefined value or generate new blocks
    testData = {};

    if (!udsOnCan) {
        std::cerr << "UDSonCAN instance is not initialized." << std::endl;
        return;
    }

    // Call requestDownload
    auto [downloadSuccess, downloadResponse] = udsOnCan->requestDownload(dfi, address, testData);
    if (!downloadSuccess) {
        std::cerr << "Failed to execute requestDownload" << std::endl;
        return;
    }
    // Uncomment it whenever I need fresh data
    //createHexFile("Data.hex", 1000, 512);

    std::vector<std::vector<uint8_t>> dataBlocks = parseHexFile("Data.hex");

    // Iterate over each block and send it
    uint8_t sequenceNumber = 1;
    for (auto& block : dataBlocks) {
        auto [transferSuccess, transferResponse] = udsOnCan->transferData(sequenceNumber++, block);
        if (!transferSuccess) {
            std::cerr << "Failed to transfer data chunk " << static_cast<int>(sequenceNumber) << std::endl;
            return;
        }
    }

    //Call RequestTransferExit
    testData = {};

    auto [exitSuccess, exitResponse] = udsOnCan->requestTransferExit(testData);
    if (!exitSuccess) {
        std::cerr << "Failed to execute requestDownload" << std::endl;
        return;
    }
}

void Tester::medium_update(uint8_t dfi, uint32_t address) {
    //TODO
}

std::vector<std::vector<uint8_t>> Tester::generateRandomDataBlocks(int numBlocks, int blockSize) {
    std::vector<std::vector<uint8_t>> dataBlocks;
    dataBlocks.reserve(numBlocks);

    // Seed the random number generator
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    for (int i = 0; i < numBlocks; ++i) {
        std::vector<uint8_t> block;
        block.reserve(blockSize);

        for (int j = 0; j < blockSize; ++j) {
            block.push_back(static_cast<uint8_t>(std::rand() % 256));
        }

        dataBlocks.push_back(block);
    }

    return dataBlocks;
}

void Tester::createHexFile(const std::string& filename, int numBlocks, int blockSize) {
    auto dataBlocks = generateRandomDataBlocks(numBlocks, blockSize);
    
    std::ofstream hexFile(filename);
    if (!hexFile.is_open()) {
        std::cerr << "Unable to create HEX file." << std::endl;
        return;
    }

    for (const auto& block : dataBlocks) {
        for (auto byte : block) {
            hexFile << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(byte);
        }
        hexFile << std::endl; // New line for next block
    }

    hexFile.close();
}

std::vector<std::vector<uint8_t>> Tester::parseHexFile(const std::string& filename) {
    std::ifstream hexFile(filename);
    std::vector<std::vector<uint8_t>> dataBlocks;

    if (!hexFile.is_open()) {
        std::cerr << "Unable to open HEX file." << std::endl;
        return dataBlocks;
    }

    std::string line;
    while (std::getline(hexFile, line)) {
        std::vector<uint8_t> block;
        std::istringstream hexStream(line);
        std::string byteString;

        while (hexStream >> std::setw(2) >> byteString) {
            uint8_t byte = static_cast<uint8_t>(std::stoul(byteString, nullptr, 16));
            block.push_back(byte);
        }

        if (!block.empty()) {
            dataBlocks.push_back(block);
        }
    }

    hexFile.close();
    return dataBlocks;
}

